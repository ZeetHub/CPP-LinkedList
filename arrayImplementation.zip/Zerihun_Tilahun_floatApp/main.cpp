/* Name: Zerihun Tilahun Eshete
   ID: TD 3767 */
#include<iostream>
using namespace std;
#include "LinkedList.cpp"

const int MAX = 200;
enum{ADD_FLOAT = 1, REMOVE_FLOAT, SEARCH, UPDATE, DISPLAY, COUNT, CLEAR, EXIT};

int menu();

int main()
{
    BaseArray<float> base;
    initializeBaseArray(base, MAX);
    LinkedList<float>list;
    createList(list, &base, true);

int choice;
    do
    {
        choice = menu();
        do
        {
            int size;
            char accept;
            bool found = false;
            switch(choice)
            {
                case ADD_FLOAT:
                {
                    float newData;
                    bool inserted = false, resized = false;
                    do
                    {
                        cout<<"How many numbers would you like to insert? ";
                        cin>>size;
                        system("cls");
                        for(int i=0;i<size;i++)
                        {
                            cout<<"Input the number you would like to insert: ";
                            cin>>newData;
                            inserted = insert(list, newData);
                            if(inserted == false)
                            {
                                system("cls");
                                cout<<"List size is full. Would you like to change the current space?(y/Y/n/N) ";
                                cin>>accept;
                                system("cls");
                                if(accept == 'y' || accept == 'Y')
                                {
                                    int newSize;
                                    cout<<"Current size is "<<MAX<<". Enter a new list size: ";
                                    cin>>newSize;
                                    resized = resizeBaseArray(base,newSize);
                                    if(resized == false)
                                        cout<< "Computer doesn't have sufficient memory";
                                    else
                                        insert(list, newData);
                                }
                            }
                        }
                        system("cls");
                        cout<<"Would you like to repeat adding numbers? (y/Y/n/N): ";
                        cin>>accept;
                    } while (accept == 'y' || accept == 'Y');
                }
                    break;
                case REMOVE_FLOAT:
                {
                    float deleteData;
                    int count=0;
                    do
                    {
                        cout<<"How many numbers would you like to delete? ";
                        cin>>size;
                        system("cls");
                        for(int i=0;i<size;i++)
                        {
                            if(i==0)
                            {
                                if(count == 0)
                                    cout<< "Enter the first number to delete: ";
                                else
                                    cout<<"Okay. Enter again the first number to delete: ";
                            }
                            else
                            {
                                if(count == 0)
                                        cout<< "Enter the next number to delete: ";
                                else
                                    cout<<"Okay. Enter again the right number to delete: ";
                            }
                            cin>>deleteData;
                            system("cls");
                            found = remove(list, deleteData);
                            if(found == false)
                            {
                                cout<< deleteData<<" does not exist in the list. Did you put the wrong number?(y/Y/n/N) ";
                                cin>>accept;
                                system("cls");
                                if(accept == 'y' || accept == 'Y')
                                {
                                    i--;
                                    count++;
                                }
                                else
                                    count = 0;
                            }
                            else
                                count = 0;
                        }
                        system("cls");
                        cout<<"Would you like to repeat the deletion? (y/Y/n/N): ";
                        cin>>accept;
                    } while (accept == 'y' || accept == 'Y');
                }
                    break;
                case SEARCH:
                {
                    int pos;
                    float searchNum;
                    do
                    {
                        cout<<"Enter the number you would like to search: ";
                        cin>>searchNum;
                        system("cls");
                        found = search(list, searchNum, pos);
                        if(found)
                            cout<<searchNum<<" is found at index "<<pos<<"."<<endl;
                        else
                            cout<<searchNum<<" is not found in list"<<endl;
                        system("pause");
                        system("cls");
                        cout<<"Would you like to repeat the searching? (y/Y/n/N): ";
                        cin>>accept;
                        system("cls");
                    } while (accept == 'y' || accept == 'Y');
                }
                    break;
                case UPDATE:
                {
                    int pos;
                    float searchNum, updateNum;
                    do
                    {
                        cout<<"Enter the number you would like to replace: ";
                        cin>>searchNum;
                        cout<<"Enter the new number you would like to add: ";
                        cin>>updateNum;
                        system("cls");
                        found = update(list, searchNum, updateNum);
                        if(found)
                            cout<<searchNum<<" is found and replaced with " <<updateNum<<"."<<endl;
                        else
                            cout<<searchNum<<" is not found."<<endl;
                        system("pause");
                        system("cls");
                        cout<<"Would you like to repeat the updating process? (y/Y/n/N): ";
                        cin>>accept;
                        system("cls");
                    } while (accept == 'y' || accept == 'Y');
                }
                    break;
                case DISPLAY:
                    displayList(list);
                    break;
                case COUNT:
                    {
                        int cnt=0;
                        count(list, cnt);
                        cout<<"The number of elements is "<<cnt<<"."<<endl;
                        system("pause");
                        system("cls");
                    }
                    break;
                case CLEAR:
                    {
                        returnList(list, list.head, list.tail);
                        cout<<"list is now empty.\n";
                        system("pause");
                        system("cls");
                    }
                    break;
                case EXIT:
                    {
                        cout<<"Exiting Program\n\n";
                        system("pause");
                        system("cls");
                    }
                    break;
            }
            system("cls");
        } while (choice<ADD_FLOAT || choice>EXIT);
    } while (choice != EXIT);

}

int menu()
{
    int choice, invalid=0;
    do
    {
        if(invalid == 1)
        {
            cout<<setfill('-')<<setw(52)<<'-'<<setfill(' ')<<endl;
            cout << "Invalid choice! Please select an appropriate number: "<<endl;
        }
        else
        {
            cout<<setfill('-')<<setw(35)<<'-'<<setfill(' ')<<endl;
            cout<< "Choose from the menu below: "<<endl;
        }
        cout<< "1. Add float\n2. Remove float\n3. Search\n4. Update\n5. Display\n6. Count\n7. Clear\n8. Exit \n";
        cout<< "Enter the number of your choice: ";
        cin>>choice;
        if(choice < ADD_FLOAT || choice > EXIT)
            invalid = 1;
        else
            invalid = 0;
        system("cls");
    } while (invalid == 1);

    return choice;

}
