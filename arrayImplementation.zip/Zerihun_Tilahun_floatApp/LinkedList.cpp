/* Name: Zerihun Tilahun Eshete
   ID: TD 3767 */

#include<cstdlib>
#include<iomanip>
const int NIL = -1;

//BASE ARRAY
template <class T>
struct node//Create a node
{
    T data;
    int next;
};

template <class T>
struct BaseArray
{
    node<T> *base;
    int capacity;
    int available;
};

//LINKEDLIST
template <class T>
struct LinkedList
{
    BaseArray<T> *array;
    int head;
    int tail;
    bool sorted;
};

//BASE ARRAY FUNCTION INTERFACES
template <class T>
bool initializeBaseArray(BaseArray<T> &array, int capacity);
template <class T>
bool isFull(BaseArray<T> array);
template <class T>
int getNode(BaseArray<T> &array);
template <class T>
void returnNode(BaseArray<T> &array, int p);
template <class T>
bool resizeBaseArray(BaseArray<T> &array, int newCapacity);
template <class T>
void returnList(LinkedList<T> &list, int listHead, int listTail);
template <class T>
void destroyBaseArray(BaseArray<T> &array);

//LINKEDLIST FUNCTION INTERFACES
// template <class T>
// void createList(LinkedList<T> &list, BaseArray<T>*base, bool sorted=false);
template <class T>
int isEmpty(LinkedList<T> list);
template <class T>
static void insertNode(LinkedList<T> &list, int p, int prev);
template <class T>
static int insertSlot(LinkedList<T> list, int p);
template <class T>
bool insert(LinkedList<T> &list, T newData);
template <class T>
static int deleteNode(LinkedList<T> &list, int prev);
template <class T>
static bool nodeToDelete(LinkedList<T>list, T targetData, int &prev);
template <class T>
bool remove(LinkedList<T> &list, T targetData);

//OTHER FUNCTION INTERFACES
template <class T>
static bool search(LinkedList<T>list, T targetData, int &pos);
template <class T>
bool update(LinkedList<T>& list, T targetData, T replaceData);
template <class T>
void displayList(LinkedList<T> list);
template <class T>
void count(LinkedList<T>list, int &cnt);


template <class T>
bool initializeBaseArray(BaseArray<T> &array, int capacity)
{
    array.base = new(nothrow)node<T>[capacity];
    if(array.base)
    {
        array.capacity = capacity;
        for(int i=0;i<=array.capacity-2;i++)
        {
            array.base[i].next = i+1;
        }
        array.base[array.capacity-1].next = NIL;
        array.available = 0;
        return true;
    }

    return false;
}

template <class T>
bool isFull(BaseArray<T> array)
{
    return array.available == NIL;
}

template <class T>
int getNode(BaseArray<T> &array)
{
    int p=NIL;
    if(!isFull(array))
    {
        p=array.available; 
        array.available = array.base[array.available].next;
    }   
    return p;
}

template <class T>
void returnNode(BaseArray<T> &array, int p) 
{
    array.base[p].next = array.available;
    array.available = p;
}

template<class T>
bool resizeBaseArray(BaseArray<T> &array, int newCapacity)
{
    BaseArray<T> temp;
    temp.base = new(nothrow)node<T>[newCapacity];
    if(temp.base)
    {
        for(int i=0;i<array.capacity;i++)
        {
            temp.base[i].data = array.base[i].data;
            temp.base[i].next = array.base[i].next;
        }

        delete []array.base;

        BaseArray<T> array;
        array.base = new(nothrow)node<T>[newCapacity];
        for(int i=0;i<array.capacity;i++)
        {
            array.base[i].data = temp.base[i].data;
            array.base[i].next = temp.base[i].next;
        }
        for(int i = array.capacity-1;i<newCapacity-1;i++)
        {
            array.base[i].next = i+1;
        }
        array.base[newCapacity-1].next = NIL;
        array.available = array.capacity;
        array.capacity = newCapacity;

        delete []temp.base;
        return true;
    }
    
    return false;

}

template <class T>
void returnList(LinkedList<T> &list, int listHead, int listTail)
{
    listTail = list.array->available; 
    list.array->available = listHead;

    delete []list.array;
}

template<class T>
void destroyBaseArray(BaseArray<T> &array)
{
    delete [] array.base;
}

//LINKEDLIST
template <class T>
void createList(LinkedList<T> &list, BaseArray<T>*base, bool sorted=false)
{
    list.array = base;
    list.head=list.tail=NIL;
    list.sorted=sorted;
}

template <class T>
int isEmpty(LinkedList<T> list)
{
    return list.head == NIL;
}

template <class T>
static void insertNode(LinkedList<T> &list, int p, int prev)
{
    if(list.head == NIL)
    {
        list.array->base[p].next = NIL;
        list.head=list.tail=p;
    }
    else if(prev == NIL)
    {
        list.array->base[p].next = list.head;
        list.head = p;
    }
    else
    {
        list.array->base[p].next = list.array->base[prev].next;
        list.array->base[prev].next = p;
        if(prev == list.tail)
            list.tail = p;
    }

}

template <class T>
static int insertSlot(LinkedList<T> list, int p)//This function is used only when dealing with a sorted list. Also note that the list is assed here by value.
{
    //return a pointer to the preceding element after which node p is to be inserted.
    int found=0;
    int prev=NIL;
    while(list.head != NIL && !found)
    {
        if(list.array->base[list.head].data < list.array->base[p].data)
        {
            prev = list.head;
            list.head = list.array->base[list.head].next;
        }
        else
        {
            found = 1;
        }
    }
    return prev;
}


template <class T>
bool insert(LinkedList<T> &list, T newData)
{
    int p=NIL, prev;
    p=getNode(*(list.array));
    if(p != NIL)
    {
        list.array->base[p].data = newData;
        if(list.sorted == false)
            prev = list.tail;
        else
            prev = insertSlot(list, p);
        insertNode(list, p, prev);
        return true;
    }
    else
        return false;
}

template <class T>
static int deleteNode(LinkedList<T> &list, int prev)
{
    int p;
    if(list.head==list.tail)
    {
        p=list.head;
        list.head=list.tail=NIL;
    }
    else if(prev == NIL)
    {
        p=list.head;
        list.head = list.array->base[list.head].next;
    }
    else
    {
        p=list.array->base[prev].next;
        list.array->base[prev].next = list.array->base[p].next;
        if(list.array->base[prev].next == list.tail)
            list.tail = prev;
    }
    return p;
}

template <class T>
static bool nodeToDelete(LinkedList<T>list, T targetData, int &prev)
{
    int found = false, inList = true;
    prev = NIL;
    if(list.sorted == true)
    {   
        while(!found && inList)
        {
            if(list.array->base[list.head].data < targetData)
            {
                prev = list.head;
                list.head = list.array->base[list.head].next;
                if(list.head == NIL)
                {
                    inList = false;
                    return inList;
                }
            }
            else if(list.array->base[list.head].data == targetData)
            {
                found = true;
            }
            else
            {
                inList = false;
                return inList;
            }
        }
    }
    else
    {
        while(!found && list.head !=NIL)
        {
            if(list.array->base[list.head].data != targetData)
            {
                prev = list.head;
                list.head = list.array->base[list.head].next;
            }
            else
            {
                found = true;
            }
        }
    }

    return found;
}

template <class T>
bool remove(LinkedList<T> &list, T targetData)
{
    int p, prev;

    if(nodeToDelete(list, targetData, prev))
    {
        p=deleteNode(list, prev);
        returnNode(*(list.array), p);
        return true;
    }

    return false;
}

template <class T>
static bool search(LinkedList<T>list, T targetData, int &pos)
{
    int found = false, inList = true;
    pos = NIL;
    if(list.sorted == true)
    {   
        while(!found && inList)
        {
            if(list.array->base[list.head].data < targetData)
            {
                list.head = list.array->base[list.head].next;
                if(list.head == NIL)
                {
                    inList = false;
                    return inList;
                }
            }
            else if(list.array->base[list.head].data == targetData)
            {
                pos = list.head;
                found = true;
            }
            else
            {
                inList = false;
                return inList;
            }
        }
    }
    else
    {
        while(!found && list.head !=NIL)
        {
            if(list.array->base[list.head].data == targetData)
            {
                pos = list.head;
                found = true;
            }
            else
            {
                list.head = list.array->base[list.head].next;
            }
        }
    }
    return found;
}

template <class T>
bool update(LinkedList<T>& list, T targetData, T updateNum)
{
    int pos;
    bool found = false;
    found = search(list, targetData, pos);
    if(found)
        list.array->base[pos].data = updateNum;

    return found;
}

template <class T>
void displayList(LinkedList<T> list)
{
    cout<<setw(5)<<"INDEX"<<setw(5)<<setfill(' ')<<setw(10)<<"DATA"<<setfill(' ')<<setw(10)<<right<<"NEXT"<<endl;
    cout<<setfill('-')<<setw(25)<<'-'<<setfill(' ')<<endl;
    while(list.head != NIL)
    {
        cout<<setw(5)<<list.head<<setfill(' ')<<setw(10)<<right<<list.array->base[list.head].data<<setfill(' ')<<setw(10)<<list.array->base[list.head].next<<setfill(' ')<<endl;
        // cout<<list.array->base[list.head].next<<endl;
        list.head = list.array->base[list.head].next;
    }
    system("pause");
    system("cls");
}

template <class T>
void count(LinkedList<T>list, int &cnt)
{
    
    while(list.head !=NIL)
    {
        list.head = list.array->base[list.head].next;
        cnt++;
    }
}